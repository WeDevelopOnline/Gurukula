<?php

session_start();
include_once "dbconfig.php";
if(!(verifyuser_admin()))
{
echo"<h1 align='center'>You Cannot View This Page</h1>";
die();
}

?>


<!DOCTYPE html>
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<title>Gurukula</title>
		<link rel="icon" href="images/favicon.phg" type="image/x-icon" />
		<meta name="description" content="Teaching Institute">
		<meta name="author" content="vikash mishra">

		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Favicon 
		<link rel="shortcut icon" href="images/favicon.ico">-->

		<!-- Web Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700,300&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>

		<!-- Bootstrap core CSS -->
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">

		<!-- Font Awesome CSS -->
		<link href="fonts/font-awesome/css/font-awesome.css" rel="stylesheet">

		<!-- Plugins -->
		<link href="css/animations.css" rel="stylesheet">

		<!-- Gurukula core CSS file -->
		<link href="css/style.css" rel="stylesheet">

		<!-- Custom css --> 
		<link href="css/custom.css" rel="stylesheet">
	</head>

	<body class="no-trans" >
		<!-- scrollToTop -->
		<!-- ================ -->
		<div class="scrollToTop"><i class="icon-up-open-big"></i></div>

		<!-- header start -->
		<!-- ================ --> 
		<header class="header fixed clearfix  navbar navbar-fixed-top">
			<div class="container">
				<div class="row">
					<div class="col-md-4">

						<!-- header-left start -->
						<!-- ================ -->
						<div class="header-left clearfix">

							<!-- logo -->
							<div class="logo smooth-scroll">
								<a href="#banner"><img id="logo" src="images/logo.png" alt="Gurukula"></a>
							</div>

							

						</div>
						<!-- header-left end -->

					</div>
					<div class="col-md-8">

						<!-- header-right start -->
						<!-- ================ -->
						<div class="header-right clearfix">

							<!-- main-navigation start -->
							<!-- ================ -->
							<div class="main-navigation animated">

								<!-- navbar start -->
								<!-- ================ -->
								<nav class="navbar navbar-default" role="navigation">
									<div class="container-fluid">

										<!-- Toggle get grouped for better mobile display -->
										<div class="navbar-header">
											<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
												<span class="sr-only">Toggle navigation</span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
											</button>
										</div>

										<!-- Collect the nav links, forms, and other content for toggling -->
										<div class="collapse navbar-collapse scrollspy smooth-scroll" id="navbar-collapse-1">
											<ul class="nav navbar-nav navbar-right">
												<li>
													<a  href="http://www.thegurukula.com" >Gurukula Home</a>
												</li>
												<li>
													<a  href="http://www.blogs.thegurukula.com">Gurukula BLOGS</a>
												</li>
												<li>
													<a  href="logout.php">LOGOUT</a>
												</li>
												
											</ul>
										</div>

									</div>
								</nav>
								<!-- navbar end -->

							</div>
							<!-- main-navigation end -->

						</div>
						<!-- header-right end -->

					</div>
				</div>
			</div>
		</header>
		<!-- header end -->

		
		
		
		<div class="jumbotron " align="center" style="padding-top:150px;">
		<div class="container">
		<h2 align="center">Insert Into Blog</h2>
			<form role="form" id="footer-form" method="POST" enctype="multipart/form-data">
									<div class="form-group has-feedback">
										<label class="sr-only" >BLOG TITLE</label>
										<input type="text" class="form-control" id="head" placeholder="BLOG TITLE" name="head" required>
										<i class="fa fa-star form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">	
										<label class="sr-only" >AUTHOR</label>
										<input type="text" class="form-control" id="author" placeholder="Author Name" name="author" required>
										<i class="fa fa-user form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >TIME</label>
										<input type="text" class="form-control" id="time" placeholder="Time Eg: 03-07-2015 17:40 HRS" name="time" required>
										<i class=" glyphicon glyphicon-time form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >BLOG Content</label>
										<textarea class="form-control" rows="8" id="body" placeholder="BLOG Content" name="body" required></textarea>
										<i class="fa fa-pencil form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Select Image If Any</label>
										<input type="file" name="image" id="image" title="Choose Image File Only">
										<i class="glyphicon glyphicon-picture "></i>
									</div>
									
									<input type="submit" name="submit" id="submit" value="Send" class="btn btn-default">
								</form>
		</div>
		</div>
		
		
		<div class="jumbotron " align="center" style="margin-top:150px;">
		<div class="container">
		<h2 align="center">Insert Public Questions</h2>
			<form role="form" id="footer-form" method="POST" enctype="multipart/form-data">
									<div class="form-group has-feedback">
										<label class="sr-only" >Question</label>
										<input type="text" class="form-control" id="question" placeholder="Question" name="question" required>
										<i class="fa fa-star form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Select Image If Any</label>
										<input type="file" name="image" id="image" title="Choose Image File Only">
										<i class="glyphicon glyphicon-picture "></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Answer</label>
										<input type="text" class="form-control" id="answer" placeholder="Answer" name="answer" required>
										<i class="fa fa-pencil form-control-feedback"></i>
									</div>
									
									
									
									<input type="submit" name="submit2" id="submit2" value="Upload" class="btn btn-default">
								</form>
		</div>
		</div>
		
		
		
		<div class="jumbotron " align="center" style="margin-top:150px;">
		<div class="container">
		<h2 align="center">Insert Private Questions</h2>
			<form role="form" id="footer-form" method="POST" enctype="multipart/form-data">
									<div class="form-group has-feedback">
										<label class="sr-only" >Question</label>
										<input type="text" class="form-control" id="question" placeholder="Question" name="question" required>
										<i class="fa fa-star form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Select Image If Any</label>
										<input type="file" name="image" id="image" title="Choose Image File Only">
										<i class="glyphicon glyphicon-picture "></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Answer</label>
										<input type="text" class="form-control" id="answer" placeholder="Answer" name="answer" required>
										<i class="fa fa-pencil form-control-feedback"></i>
									</div>
									
									
									
									<input type="submit" name="submit3" id="submit3" value="Upload" class="btn btn-default">
								</form>
		</div>
		</div>
		
		
		<div class="jumbotron " align="center" style="margin-top:150px;">
		<div class="container">
		<h2 align="center">Add Students</h2>
			<form role="form" id="footer-form" method="POST" enctype="multipart/form-data">
									<div class="form-group has-feedback">
										<label class="sr-only" >Full Name</label>
										<input type="text" class="form-control" id="name" placeholder="Full Name" name="name" required>
										<i class="fa fa-star form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >User ID</label>
										<input type="text" class="form-control" id="username" placeholder="User ID" name="username" required>
										<i class="fa fa-star form-control-feedback"></i>
									</div>
									<div class="form-group has-feedback">
										<label class="sr-only" >Password</label>
										<input type="text" class="form-control" id="pass" placeholder="Password" name="pass" required>
										<i class="fa fa-pencil form-control-feedback"></i>
									</div>
									
									
									
									<input type="submit" name="submit4" id="submit4" value="Add Student" class="btn btn-default">
								</form>
		</div>
		</div>
		
		
		<div class="jumbotron " align="center" style="margin-top:150px;">
		<div class="container">
		<h2 align="center">Remove Students</h2>
			<form role="form" id="footer-form" method="POST" enctype="multipart/form-data">
									
									<div class="form-group has-feedback">
										<label class="sr-only" >Student's User ID</label>
										<input type="text" class="form-control" id="username" placeholder="Student's User ID" name="username" required>
										<i class="fa fa-pencil form-control-feedback"></i>
									</div>
									
									
									
									<input type="submit" name="submit5" id="submit5" value="Remove Student" class="btn btn-default">
								</form>
		</div>
		</div>
		
		
		<div class="jumbotron " align="center" style="margin-top:150px;">
		<div class="container">
		
		<h2>Upload Notes</h2>
<form method='post' enctype='multipart/form-data'>
select a file to upload
<input type='file' name='myfile' id='myfile' />
<br />
<input type='submit' name='upload' id='upload' value='upload' />
</form>
<?php
include_once "dbconfig.php";
if(isset($_REQUEST['upload']))
{
$error=$_FILES['myfile']['error'];
	if($error!=0)
	{
	echo "<Br />A File not uploaded, server seems busy, try later";
	}
	else
	{
	$fname=$_FILES['myfile']['name'];
	$ftype=$_FILES['myfile']['type'];
	$fsize=$_FILES['myfile']['size'];
	$ftname=$_FILES['myfile']['tmp_name'];

	$fp=fopen($ftname,'r');
	$filedata=fread($fp,$fsize);
		

	$filedata=addslashes($filedata);
		$query="insert into notes (filename,filetype,filesize,filedata) values ('$fname','$ftype',$fsize,'$filedata')";
		$n=my_iud($query);
		if($n==1)
		{
			echo "<Br />File upload successful";
		}
		else
		{
	echo "<Br />C File not uploaded, server seems busy, try later";
		}
	
	
	}
}




?>
		
		</div>
		</div>
		
		<?php
		
		if(isset($_POST['submit2']))
					{
						$question=$_POST['question'];
						$answer=$_POST['answer'];
						
						
						
						$fsize=$_FILES['image']['size'];
						$image=$_FILES['image']['tmp_name'];

						$fp=fopen($image,'r');
						$filedata=fread($fp,$fsize);
							

						$filedata=addslashes($filedata);
											
						
						$query="INSERT INTO `free_stuff`( `question`, `image`, `answer`) VALUES ('$question','$filedata','$answer');";
						
						$n=my_iud($query);
						
						if($n)
							echo"<script> alert('QUESTION SUBMITTED SUCCESSFULLY')</script>";
						else
							echo"<script> alert('Something went wrong please try again :( ..!')</script>";
		
					}else if(isset($_POST['submit']))
					{
						$head=$_POST['head'];
						$author=$_POST['author'];
						$time=$_POST['time'];
						$body=$_POST['body'];
						
						
						$fsize=$_FILES['image']['size'];
						$image=$_FILES['image']['tmp_name'];

						$fp=fopen($image,'r');
						$filedata=fread($fp,$fsize);
							

						$filedata=addslashes($filedata);
											
						
						$query="INSERT INTO `blog`( `heading`, `author`, `time`, `body`, `image`) VALUES ('$head','$author','$time','$body','$filedata');";
						
						$n=my_iud($query);
						
						if($n)
							echo"<script> alert('BLOG SUBMITTED SUCCESSFULLY')</script>";
						else
							echo"<script> alert('Something went wrong please try again :( ..!')</script>";
		
					}else if(isset($_POST['submit3']))
					{
						$question=$_POST['question'];
						$answer=$_POST['answer'];
						
						
						
						$fsize=$_FILES['image']['size'];
						$image=$_FILES['image']['tmp_name'];

						$fp=fopen($image,'r');
						$filedata=fread($fp,$fsize);
							

						$filedata=addslashes($filedata);
											
						
						$query="INSERT INTO `private_stuff`( `question`, `image`, `answer`) VALUES ('$question','$filedata','$answer');";
						
						$n=my_iud($query);
						
						if($n)
							echo"<script> alert('QUESTION SUBMITTED SUCCESSFULLY')</script>";
						else
							echo"<script> alert('Something went wrong please try again :( ..!')</script>";
		
					}else if(isset($_POST['submit5']))
					{
						$username=$_POST['username'];
											
						$query="DELETE FROM `student_login` WHERE username='$username';";
						
						$n=my_iud($query);
						
						if($n)
							echo"<script> alert('STUDENT REMOVED SUCCESSFULLY')</script>";
						else
							echo"<script> alert('Something went wrong please try again :( ..!')</script>";
		
					}else if(isset($_POST['submit4']))
					{
						$name=$_POST['name'];
						$username=$_POST['username'];
						$pass=$_POST['pass'];
											
						$query="INSERT INTO `student_login`( `name`, `username`, `password`) VALUES ('$name','$username','$pass');";
						
						$n=my_iud($query);
						
						if($n)
							echo"<script> alert('STUDENT ADDED SUCCESSFULLY')</script>";
						else
							echo"<script> alert('Something went wrong please try again :( ..!')</script>";
		
					}
		
		
		
		
		?>
		
		
		
		
		
		
		
<!-- JavaScript files placed at the end of the document so the pages load faster
		================================================== -->
		<!-- Jquery and Bootstap core js files -->
		<script type="text/javascript" src="plugins/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

		<!-- Modernizr javascript -->
		<script type="text/javascript" src="plugins/modernizr.js"></script>

		<!-- Isotope javascript -->
		<script type="text/javascript" src="plugins/isotope/isotope.pkgd.min.js"></script>
		
		<!-- Backstretch javascript -->
		<script type="text/javascript" src="plugins/jquery.backstretch.min.js"></script>

		<!-- Appear javascript -->
		<script type="text/javascript" src="plugins/jquery.appear.js"></script>

		<!-- Initialization of Plugins -->
		<script type="text/javascript" src="js/template.js"></script>

		<!-- Custom Scripts -->
		<script type="text/javascript" src="js/custom.js"></script>
		
</body>
</html>
			