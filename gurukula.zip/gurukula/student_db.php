<?php

session_start();
include_once "dbconfig.php";
if(!(verifyuser()))
{
echo"<h1 align='center'>You Cannot View This Page</h1>";
die();
}

?>


<!DOCTYPE html>
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<title>Gurukula</title>
		<link rel="icon" href="images/favicon.phg" type="image/x-icon" />
		<meta name="description" content="Teaching Institute">
		<meta name="author" content="vikash mishra">

		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Favicon 
		<link rel="shortcut icon" href="images/favicon.ico">-->

		<!-- Web Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700,300&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>

		<!-- Bootstrap core CSS -->
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">

		<!-- Font Awesome CSS -->
		<link href="fonts/font-awesome/css/font-awesome.css" rel="stylesheet">

		<!-- Plugins -->
		<link href="css/animations.css" rel="stylesheet">

		<!-- Gurukula core CSS file -->
		<link href="css/style.css" rel="stylesheet">

		<!-- Custom css --> 
		<link href="css/custom.css" rel="stylesheet">
	</head>

	<body class="no-trans" >
		<!-- scrollToTop -->
		<!-- ================ -->
		<div class="scrollToTop"><i class="icon-up-open-big"></i></div>

		<!-- header start -->
		<!-- ================ --> 
		<header class="header fixed clearfix  navbar navbar-fixed-top">
			<div class="container">
				<div class="row">
					<div class="col-md-4">

						<!-- header-left start -->
						<!-- ================ -->
						<div class="header-left clearfix">

							<!-- logo -->
							<div class="logo smooth-scroll">
								<a href="#banner"><img id="logo" src="images/logo.png" alt="Gurukula"></a>
							</div>

							

						</div>
						<!-- header-left end -->

					</div>
					<div class="col-md-8">

						<!-- header-right start -->
						<!-- ================ -->
						<div class="header-right clearfix">

							<!-- main-navigation start -->
							<!-- ================ -->
							<div class="main-navigation animated">

								<!-- navbar start -->
								<!-- ================ -->
								<nav class="navbar navbar-default" role="navigation">
									<div class="container-fluid">

										<!-- Toggle get grouped for better mobile display -->
										<div class="navbar-header">
											<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
												<span class="sr-only">Toggle navigation</span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
											</button>
										</div>

										<!-- Collect the nav links, forms, and other content for toggling -->
										<div class="collapse navbar-collapse scrollspy smooth-scroll" id="navbar-collapse-1">
											<ul class="nav navbar-nav navbar-right">
												<li>
													<a  href="http://www.thegurukula.com" >Gurukula Home</a>
												</li>
												<li>
													<a  href="http://www.blogs.thegurukula.com">Gurukula BLOGS</a>
												</li>
												<li>
													<a  href="notes.php">Download Notes</a>
												</li>
												<li>
													<a  href="logout.php">LOGOUT</a>
												</li>
												
											</ul>
										</div>

									</div>
								</nav>
								<!-- navbar end -->

							</div>
							<!-- main-navigation end -->

						</div>
						<!-- header-right end -->

					</div>
				</div>
			</div>
		</header>
		<!-- header end -->

		
		
		<div class="container jumbotron" style="padding-top:150px; background:transparent;">
            
                <div class="col-sm-12" align="center">
                    <h2 style="color:#ff6d06" ><strong>WELCOME <?php echo fetchusername();?></strong></h2>
                    <p>Go through the question numbers allotted to you...</p>
                </div>
				
				
                    
				<div >	
					<?php

include_once"dbconfig.php";

$query="SELECT * FROM `private_stuff` ORDER BY sno ;";


$rs=my_select($query);
								
								$a=1;
								while($row=mysql_fetch_array($rs))
								{
									echo"<div class='col-sm-12 jumbotron' style='background:transparent;'>";
									if($a%2==0)
									{
										
									echo " <h3 align='left' style='color:#ff6d06'>Question Number : $row[0]</h3>";
									echo "<p><blockquote align='justify'><strong>$row[1]</strong><br/>&nbsp;";
									if (!($row['image']==NULL))
									echo '<img class="img-responsive" src="data:image;base64,'.base64_encode($row['image']) .'"><br/>';
									else echo"<br/>&nbsp;";
									echo "<footer>Answer :<strong> $row[3] </strong>&nbsp;</footer></blockquote></p>";
									
									}
									else
									{
									echo " <h3 align='right' style='color:#ff6d06'>Question Number : $row[0]</h3>";
									echo "<p><strong><blockquote class='blockquote-reverse' align='justify'>$row[1]</strong><br/>&nbsp;";
									if (!($row['image']==NULL))
									echo '<img class="img-responsive" src="data:image;base64,'.base64_encode($row['image']) .'"><br/>';
									else echo"<br/> &nbsp;";
									echo "<footer>Answer : <strong> $row[3] </strong>&nbsp;</footer></blockquote></p>";
									
									}
										
											$a++;
									echo "</div>";
								}
								


?>
					
					
					
					
					
					
                    
            </div>
        </div>
		
		
		
		
		
		
		
		
		
		
		
		
		
<!-- JavaScript files placed at the end of the document so the pages load faster
		================================================== -->
		<!-- Jquery and Bootstap core js files -->
		<script type="text/javascript" src="plugins/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

		<!-- Modernizr javascript -->
		<script type="text/javascript" src="plugins/modernizr.js"></script>

		<!-- Isotope javascript -->
		<script type="text/javascript" src="plugins/isotope/isotope.pkgd.min.js"></script>
		
		<!-- Backstretch javascript -->
		<script type="text/javascript" src="plugins/jquery.backstretch.min.js"></script>

		<!-- Appear javascript -->
		<script type="text/javascript" src="plugins/jquery.appear.js"></script>

		<!-- Initialization of Plugins -->
		<script type="text/javascript" src="js/template.js"></script>

		<!-- Custom Scripts -->
		<script type="text/javascript" src="js/custom.js"></script>
		
</body>
</html>
			